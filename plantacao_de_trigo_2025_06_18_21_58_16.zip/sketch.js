let wheatPlants = []; // Array para armazenar todas as nossas plantas de trigo
const numberOfPlants = 50; // Quantidade de plantas que queremos no campo

function setup() {
  createCanvas(600, 400); // Cria o nosso canvas
  background(135, 206, 235); // Fundo azul celeste
  initializeWheatField(); // Chama a função para plantar o trigo automaticamente
}

function draw() {
  // Desenha o céu e a terra a cada frame para limpar o desenho anterior
  background(135, 206, 235); // Fundo azul celeste
  fill(139, 69, 19); // Cor marrom para o solo
  rect(0, height / 2, width, height / 2);

  // Atualiza e exibe cada planta de trigo
  for (let i = 0; i < wheatPlants.length; i++) {
    wheatPlants[i].grow(); // Faz o trigo crescer
    wheatPlants[i].display(); // Desenha o trigo
  }
}

function initializeWheatField() {
  // Preenche o campo com a quantidade desejada de plantas
  for (let i = 0; i < numberOfPlants; i++) {
    // Posições X e Y aleatórias dentro da área do solo
    let randomX = random(width);
    let randomY = random(height / 2 + 10, height - 10); // Garante que a planta esteja no solo
    let newWheat = new Wheat(randomX, randomY);
    wheatPlants.push(newWheat);
  }
}

// --- Classe Wheat ---
class Wheat {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.growthStage = 0; // 0: semente, 1: broto, 2: planta jovem, 3: madura
    this.maxGrowthStage = 3;
    this.growthSpeed = random(0.003, 0.007); // Velocidade de crescimento aleatória para variar
    this.plantHeight = 0; // Altura atual da planta
    this.maxPlantHeight = 50; // Altura máxima de uma planta madura
    this.color = color(139, 69, 19); // Cor da semente
  }

  grow() {
    // Aumenta o estágio de crescimento ao longo do tempo
    if (this.growthStage < this.maxGrowthStage) {
      this.growthStage += this.growthSpeed;
      // Mapeia o estágio de crescimento para a altura da planta
      this.plantHeight = map(this.growthStage, 0, this.maxGrowthStage, 0, this.maxPlantHeight);

      // Altera a cor com base no estágio de crescimento
      if (this.growthStage >= 0 && this.growthStage < 1) {
        this.color = color(139, 69, 19); // Cor da semente/broto (amarronzada)
      } else if (this.growthStage >= 1 && this.growthStage < 2) {
        this.color = color(100, 200, 50); // Cor da planta jovem (verde)
      } else if (this.growthStage >= 2 && this.growthStage <= 3) {
        this.color = color(220, 180, 50); // Cor do trigo maduro (dourado)
      }
    }
  }

  display() {
    push(); // Salva o estilo de desenho atual
    translate(this.x, this.y); // Move a origem para a posição da planta

    noStroke();
    fill(this.color);

    if (this.growthStage < 1) {
      // Desenha uma pequena semente/broto
      ellipse(0, 0, 5, 5);
    } else {
      // Desenha o talo
      rect(-2, 0, 4, -this.plantHeight);

      // Desenha algumas folhas (triângulos simples por enquanto)
      if (this.growthStage >= 1) {
        triangle(-2, -this.plantHeight / 2, -10, -this.plantHeight / 4, -2, -this.plantHeight / 4);
        triangle(2, -this.plantHeight / 2, 10, -this.plantHeight / 4, 2, -this.plantHeight / 4);
      }

      // Desenha a espiga de trigo
      if (this.growthStage >= 2) {
        fill(240, 210, 80); // Dourado mais claro para a espiga
        ellipse(0, -this.plantHeight - 5, 8, 12);
      }
    }

    pop(); // Restaura o estilo de desenho anterior
  }
}